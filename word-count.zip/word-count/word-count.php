<?php
/*
Plugin Name: Word Count
Plugin URI: www.rajtechbd.com
Description: This is the wordpress post word count calculations.
Version: 1.0
Author: RajTech
Author URI: www.faisal.rajtechbd.com
License: GPLv2 or later
Text Domain: rtech
Domain Path: /langusges/
*/

function rtech_load_text_domain(){
    load_textdomain('rtech', false, dirname(__FILE__) . "/languages");
}
add_action('plugins_loaded', 'rtech_load_text_domain');

function rtech_word_count( $content ){
 $stripped_content = strip_tags( $content );
 $wornc = str_word_count( $stripped_content );
 $label = __('Total Number of Word', 'rtech');
 $label = apply_filters('rtech_heading', $label);
 $tag = apply_filters('rtech_tag', 'h2');
 $content .= sprintf('<%s>%s: %s</%s>',$tag, $label,$wornc, $tag);
    return $content;

}
add_filter("the_content", "rtech_word_count");

function rtech_reading_time( $content ) {
    $stripped_content = strip_tags( $content );
    $wornc = str_word_count( $stripped_content );
    $reading_minite = floor( $wornc / 200 );
    $reading_second = floor( $wornc % 200 / ( 200 / 60 ) );
    $is_visible = apply_filters( 'rtech_display_reading_time', 1 );
    if( $is_visible ){
        $label = __('Total Reading Time', 'rtech');
        $label = apply_filters('rtech_reading_heading', $label);
        $tag = apply_filters('rtech_reading_time_tag', 'h4');
        $content .= sprintf('<%s>%s: %s minutes %s seconds</%s>',$tag, $label,$reading_minite,$reading_second, $tag);
    }
    return $content;
}
add_filter("the_content", "rtech_reading_time");